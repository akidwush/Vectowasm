namespace Vecto.Core;

/// <summary>
/// Keep the original Vecto.Core call sites byte-for-byte unchanged. Name resolution in
/// this namespace routes their Parallel.For/ForEach calls through this scheduler.
/// The native branch delegates to the original TPL implementation; browser-wasm
/// uses a deterministic single-thread loop (there is no ThreadPool worker to wait on).
/// Per-row and per-chain operations are independent in the original Vecto engine.
/// </summary>
internal static class Parallel
{
    public static void For(int fromInclusive, int toExclusive, ParallelOptions options, Action<int> body)
    {
        if (!OperatingSystem.IsBrowser())
        {
            System.Threading.Tasks.Parallel.For(fromInclusive, toExclusive, options, body);
            return;
        }

        for (int i = fromInclusive; i < toExclusive; i++)
        {
            options.CancellationToken.ThrowIfCancellationRequested();
            body(i);
        }
    }

    public static void ForEach<T>(IEnumerable<T> items, ParallelOptions options, Action<T> body)
    {
        if (!OperatingSystem.IsBrowser())
        {
            System.Threading.Tasks.Parallel.ForEach(items, options, body);
            return;
        }

        foreach (var item in items)
        {
            options.CancellationToken.ThrowIfCancellationRequested();
            body(item);
        }
    }
}
