# Vecto — C# Blazor WebAssembly (NET 8)

Konversi arsitektur untuk menjalankan **Vecto.Core asli, tanpa penulisan ulang algoritma** di browser. Tidak mengirim gambar ke server. `Vecto.Core` disalin dari berkas yang diberikan pengguna, ke-17 file `.cs` asli dan `.csproj` dipertahankan persis; hanya **menambah** `BrowserParallel.cs` sebagai adapter scheduling browser.

## Isi proyek

- `Vecto.Core/` — 17 file C# algoritma orisinal tidak diubah; file baru `BrowserParallel.cs` melakukan scheduling serial khusus browser dan meneruskan ke TPL paralel asli di desktop.
- `Vecto.Cli.Reference/JpegDecoder.cs` — decoder JPEG asli, tetap di namespace `Vecto.Cli` (file asli dipertahankan). Referensi sumber CLI lainnya ada untuk audit; file `sixlabors.lic` tidak disertakan karena bisa berisi lisensi privat.
- `Vecto.ImageDecoding/` — adaptor decoding C# ke `RasterImage`: JPEG kustom dahulu, ImageSharp sebagai fallback; persis urutan CLI `ImageIo.Load`.
- `Vecto.Browser/` — Blazor WebAssembly standalone, UI upload → C# trace → preview → unduh SVG.
- `Vecto.Parity/` — aplikasi console untuk mencetak hash input RGBA dan output SVG, membandingkan hasil browser vs desktop dengan opsi identik.
- `docs/` — dokumen algoritma sumber.

## Jalankan di komputer dengan .NET 8 SDK

Pastikan SDK 8.x dan koneksi NuGet tersedia. Jalankan dari folder root ZIP:

```bash
dotnet restore Vecto.Browser/Vecto.Browser.csproj
dotnet run --project Vecto.Browser/Vecto.Browser.csproj
```

Buka alamat localhost yang muncul. **`dotnet` SDK tidak terpasang di lingkungan penyusunan paket ini** sehingga belum terkompilasi atau diuji di browser. Jangan anggap artifact ini build terverifikasi.

## Publish statis

```bash
dotnet publish Vecto.Browser/Vecto.Browser.csproj -c Release -o publish
```

Upload **isi** `publish/wwwroot` ke hosting static (Netlify, Nginx, dll), bukan source ZIP ke website. `dotnet publish -r browser-wasm` bukan instruksi yang perlu ditambahkan untuk standalone Blazor; SDK Blazor menghasilkan runtime WASM otomatis.

Untuk AOT opsional (lebih besar output-nya, tetapi dapat mempercepat komputasi):

```bash
dotnet workload install wasm-tools-net8
dotnet publish Vecto.Browser/Vecto.Browser.csproj -c Release -p:EnableVectoAot=true -o publish-aot
```

.NET 8/9 berakhir dukungan pada **10 November 2026**. Untuk produksi jangka panjang, migrasikan target ke .NET 10 LTS dan versi paket Blazor sepadan setelah hasil kompatibilitas divalidasi. Proyek ini sengaja ditargetkan ke .NET 8 karena diminta dan Vecto.Core aslinya menargetkan net8.0.

## Membandingkan parity C# desktop vs browser

1. Pilih file yang sama dan samakan Style, Detail, Colors, Seed, CurveFitting, dan PolygonEpsilon.
2. Lihat `Input RGBA FNV64` dan `Output SVG FNV64` di UI browser.
3. Jalankan di desktop:

```bash
dotnet run --project Vecto.Parity/Vecto.Parity.csproj -- gambar.png --detail Medium --style Auto --colors auto --max-colors 16 --seed 1 --output hasil-desktop.svg
```

Jika hash **input RGBA sama** dan hash **SVG berbeda**, periksa numerik/urutan di WASM. Jika hash input berbeda, penyebab kemungkinan decoding/metadata gambar. FNV64 adalah checksum pembanding, bukan hash kriptografis atau bukti matematis bit-exact.

## Keterbatasan (penting)

- Ini adalah **proyek sumber**, bukan berkas `.wasm` hasil publish: tidak ada .NET SDK/network untuk restore dan build di lingkungan penyiapan.
- `Parallel.For`/`Parallel.ForEach` di source asli tidak diedit. `BrowserParallel.cs` memintasnya lewat resolusi nama `Vecto.Core.Parallel` menjadi loop serial saat `OperatingSystem.IsBrowser()`; native meneruskan ke `System.Threading.Tasks.Parallel`. Kode matematis tetap, urutan pekerjaan di browser berbeda dari desktop, sehingga tetap perlu uji parity sebelum klaim output identik.
- GUI berjalan di main thread; gambar berat dapat membuat tab berhenti merespons sementara. Browser membatasi file 20 MB dan 8 MP; batas ini bukan estimasi keamanan memori yang mutlak.
- Browser mengolah gambar secara lokal; JS hanya untuk Blob URL / unduhan, tidak untuk pixel decoding atau tracing.
- Portability floating-point tidak otomatis menjamin output bit-identical antar CPU/runtime; uji hash input dan output.
- ImageSharp 4.1.3 menggunakan lisensi Six Labors Split License; tinjau kepatuhan lisensinya sebelum dipakai dalam proyek komersial.
- Arsip `ALIV-main.zip` berisi pipeline Python terpisah (bukan bagian C# Vecto), jadi **tidak digabungkan** secara diam-diam; integrasi ALIV adalah proyek tersendiri.

## Deployment ke Nexora

Dapat di-host dalam subdomain misalnya `vecto.example.com`; untuk subpath `/vecto/`, perlu sesuaikan `<base href>` di `wwwroot/index.html` dan lokasi asset static di hosting. Tidak membutuhkan Docker yang terus memproses vector di VPS; VPS hanya melayani file statis aplikasi.
