using Vecto.Core;
using Vecto.ImageDecoding;

if (args.Length < 1)
{
    Console.Error.WriteLine("Usage: dotnet run --project Vecto.Parity -- IMAGE.png [--style Auto|Crisp|Blended|Photo] [--detail Low|Medium|High] [--colors auto|N] [--max-colors N] [--seed N] [--polygons] [--epsilon X] [--output file.svg]");
    return 1;
}
try
{
    var options = new TraceOptions();
    string input = args[0];
    string? output = null;
    for (int i = 1; i < args.Length; i++)
    {
        string a = args[i];
        if (i + 1 >= args.Length && a != "--polygons") throw new ArgumentException("Missing option value: " + a);
        switch (a)
        {
            case "--style": options.Style = Enum.Parse<ImageStyle>(args[++i], true); break;
            case "--detail": options.Detail = Enum.Parse<DetailLevel>(args[++i], true); break;
            case "--colors":
                string colors = args[++i];
                if (colors.Equals("auto", StringComparison.OrdinalIgnoreCase)) options.PaletteMode = PaletteMode.Auto;
                else { options.PaletteMode = PaletteMode.FixedCount; options.ColorCount = int.Parse(colors); }
                break;
            case "--max-colors": options.MaxColors = int.Parse(args[++i]); break;
            case "--seed": options.Seed = int.Parse(args[++i]); break;
            case "--polygons": options.CurveFitting = false; break;
            case "--epsilon": options.PolygonEpsilon = double.Parse(args[++i], System.Globalization.CultureInfo.InvariantCulture); break;
            case "--output": output = args[++i]; break;
            default: throw new ArgumentException("Unknown option: " + a);
        }
    }
    var pixels = RasterDecoder.Decode(File.ReadAllBytes(input));
    var result = Tracer.Trace(pixels, options);
    var svg = SvgWriter.Write(result.Document);
    if (output is not null) File.WriteAllText(output, svg, new System.Text.UTF8Encoding(false));
    Console.WriteLine($"Dimensions: {pixels.Width}x{pixels.Height}");
    Console.WriteLine("Input RGBA FNV64: " + FnvHash.Hex(pixels.Pixels));
    Console.WriteLine("Output SVG FNV64: " + FnvHash.Text(svg));
    Console.WriteLine($"Output bytes: {System.Text.Encoding.UTF8.GetByteCount(svg)}");
    Console.WriteLine($"Regions: {result.Diagnostics.RegionCount}, nodes: {result.Diagnostics.NodeCount}, palette: {result.Document.Palette.Count}");
    return 0;
}
catch (Exception ex)
{
    Console.Error.WriteLine(ex.ToString());
    return 2;
}
